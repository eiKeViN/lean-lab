import ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic
import Lean
open Lean Meta Elab Command
def oldStalkType : Lean.Expr :=
Lean.Expr.forallE
  `R
  (Lean.Expr.sort (Lean.Level.succ (Lean.Level.param `u)))
  (Lean.Expr.forallE
    (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `inst.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 3)
    (Lean.Expr.app (Lean.Expr.const `CommRing [Lean.Level.param `u]) (Lean.Expr.bvar 0))
    (Lean.Expr.forallE
      `V
      (Lean.Expr.sort (Lean.Level.succ (Lean.Level.param `v)))
      (Lean.Expr.forallE
        (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `inst.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 7)
        (Lean.Expr.app (Lean.Expr.const `PartialOrder [Lean.Level.param `v]) (Lean.Expr.bvar 0))
        (Lean.Expr.forallE
          `E
          (Lean.Expr.sort (Lean.Level.succ (Lean.Level.param `w)))
          (Lean.Expr.forallE
            `G
            (Lean.Expr.app
              (Lean.Expr.app
                (Lean.Expr.app
                  (Lean.Expr.const
                    `OAI.KLInvariance.MomentGraph.OrderedGraph
                    [Lean.Level.param `v, Lean.Level.param `w])
                  (Lean.Expr.bvar 2))
                (Lean.Expr.bvar 1))
              (Lean.Expr.bvar 0))
            (Lean.Expr.forallE
              `B
              (Lean.Expr.app
                (Lean.Expr.app
                  (Lean.Expr.app
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.const
                            `OAI.KLInvariance.MomentGraph.Sheaf
                            [Lean.Level.param `u, Lean.Level.param `v, Lean.Level.param `w, Lean.Level.param `z])
                          (Lean.Expr.bvar 5))
                        (Lean.Expr.bvar 4))
                      (Lean.Expr.bvar 3))
                    (Lean.Expr.bvar 2))
                  (Lean.Expr.bvar 1))
                (Lean.Expr.bvar 0))
              (Lean.Expr.forallE
                `x
                (Lean.Expr.bvar 4)
                (Lean.Expr.app
                  (Lean.Expr.app
                    (Lean.Expr.app
                      (Lean.Expr.const
                        `Eq
                        [Lean.Level.max
                           (Lean.Level.succ (Lean.Level.param `z))
                           (Lean.Level.succ (Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)))])
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `LinearMap
                                              [Lean.Level.param `u,
                                               Lean.Level.param `u,
                                               Lean.Level.param `z,
                                               Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Semiring.toNonAssocSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 7))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.bvar 0)))))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `Pi.addCommMonoid [Lean.Level.param `w, Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0)))
                                (Lean.Expr.lam
                                  `e
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.BinderInfo.default)))
                              (Lean.Expr.lam
                                `i
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                            [Lean.Level.param `v, Lean.Level.param `w])
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.bvar 2))
                                  (Lean.Expr.bvar 0))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0)))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `ModuleCat.isAddCommGroup
                                          [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.BinderInfo.default))))
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.bvar 6)))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                              [Lean.Level.param `u,
                                               Lean.Level.param `v,
                                               Lean.Level.param `w,
                                               Lean.Level.param `z])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.bvar 0))))
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `Pi.module
                                      [Lean.Level.param `w, Lean.Level.param `z, Lean.Level.param `u])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0)))
                                  (Lean.Expr.lam
                                    `e
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0))))
                                    (Lean.BinderInfo.default)))
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))))
                            (Lean.Expr.lam
                              `i
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                          [Lean.Level.param `v, Lean.Level.param `w])
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 0))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 8))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.bvar 7)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.lam
                                          `e
                                          (Lean.Expr.bvar 4)
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 0)))
                                            (Lean.Expr.bvar 2))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 0)))))
                              (Lean.BinderInfo.default)))
                          (Lean.Expr.lam
                            `i
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                        [Lean.Level.param `v, Lean.Level.param `w])
                                      (Lean.Expr.bvar 5))
                                    (Lean.Expr.bvar 4))
                                  (Lean.Expr.bvar 3))
                                (Lean.Expr.bvar 2))
                              (Lean.Expr.bvar 0))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 8))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 8))
                                  (Lean.Expr.bvar 7)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.lam
                                      `e
                                      (Lean.Expr.bvar 4)
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 0)))
                                        (Lean.Expr.bvar 2))
                                      (Lean.BinderInfo.default)))
                                  (Lean.Expr.bvar 0))))
                            (Lean.BinderInfo.default)))))
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap
                                      [Lean.Level.param `u,
                                       Lean.Level.param `v,
                                       Lean.Level.param `w,
                                       Lean.Level.param `z])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))
                                (Lean.Expr.bvar 5))
                              (Lean.Expr.bvar 4))
                            (Lean.Expr.bvar 3))
                          (Lean.Expr.bvar 2))
                        (Lean.Expr.bvar 1))
                      (Lean.Expr.bvar 0)))
                  (Lean.Expr.app
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `LinearMap.mk
                                              [Lean.Level.param `u,
                                               Lean.Level.param `u,
                                               Lean.Level.param `z,
                                               Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Semiring.toNonAssocSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 7))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.bvar 0)))))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `Pi.addCommMonoid [Lean.Level.param `w, Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0)))
                                (Lean.Expr.lam
                                  `e
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.BinderInfo.default)))
                              (Lean.Expr.lam
                                `i
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                            [Lean.Level.param `v, Lean.Level.param `w])
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.bvar 2))
                                  (Lean.Expr.bvar 0))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0)))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `ModuleCat.isAddCommGroup
                                          [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.BinderInfo.default))))
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.bvar 6)))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                              [Lean.Level.param `u,
                                               Lean.Level.param `v,
                                               Lean.Level.param `w,
                                               Lean.Level.param `z])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.bvar 0))))
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `Pi.module
                                      [Lean.Level.param `w, Lean.Level.param `z, Lean.Level.param `u])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0)))
                                  (Lean.Expr.lam
                                    `e
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0))))
                                    (Lean.BinderInfo.default)))
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))))
                            (Lean.Expr.lam
                              `i
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                          [Lean.Level.param `v, Lean.Level.param `w])
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 0))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 8))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.bvar 7)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.lam
                                          `e
                                          (Lean.Expr.bvar 4)
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 0)))
                                            (Lean.Expr.bvar 2))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 0)))))
                              (Lean.BinderInfo.default)))
                          (Lean.Expr.lam
                            `i
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                        [Lean.Level.param `v, Lean.Level.param `w])
                                      (Lean.Expr.bvar 5))
                                    (Lean.Expr.bvar 4))
                                  (Lean.Expr.bvar 3))
                                (Lean.Expr.bvar 2))
                              (Lean.Expr.bvar 0))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 8))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 8))
                                  (Lean.Expr.bvar 7)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.lam
                                      `e
                                      (Lean.Expr.bvar 4)
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 0)))
                                        (Lean.Expr.bvar 2))
                                      (Lean.BinderInfo.default)))
                                  (Lean.Expr.bvar 0))))
                            (Lean.BinderInfo.default))))
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const
                                    `AddHom.mk
                                    [Lean.Level.param `z, Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommMagma.toAdd [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `AddCommSemigroup.toAddCommMagma [Lean.Level.param `z])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.bvar 2))
                                          (Lean.Expr.bvar 1))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const `AddCommMonoid.toAddCommSemigroup [Lean.Level.param `z])
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `ModuleCat.carrier
                                              [Lean.Level.param `z, Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6)))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                          [Lean.Level.param `u,
                                                           Lean.Level.param `v,
                                                           Lean.Level.param `w,
                                                           Lean.Level.param `z])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.bvar 1))
                                          (Lean.Expr.bvar 0))))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 3))
                                                (Lean.Expr.bvar 2))
                                              (Lean.Expr.bvar 1))
                                            (Lean.Expr.bvar 0))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `ModuleCat.isAddCommGroup
                                              [Lean.Level.param `z, Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6)))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                          [Lean.Level.param `u,
                                                           Lean.Level.param `v,
                                                           Lean.Level.param `w,
                                                           Lean.Level.param `z])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.bvar 1))
                                          (Lean.Expr.bvar 0))))))))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const
                                  `AddCommMagma.toAdd
                                  [Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const
                                    `AddCommSemigroup.toAddCommMagma
                                    [Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.bvar 0)))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `AddCommMonoid.toAddCommSemigroup
                                      [Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `Pi.addCommMonoid [Lean.Level.param `w, Lean.Level.param `z])
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.bvar 2))
                                          (Lean.Expr.bvar 0)))
                                      (Lean.Expr.lam
                                        `e
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.bvar 2))
                                          (Lean.Expr.bvar 0))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.bvar 7)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 4)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 2))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 0))))
                                        (Lean.BinderInfo.default)))
                                    (Lean.Expr.lam
                                      `i
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 0))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `ModuleCat.carrier
                                                  [Lean.Level.param `z, Lean.Level.param `u])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 7)))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                              [Lean.Level.param `u,
                                                               Lean.Level.param `v,
                                                               Lean.Level.param `w,
                                                               Lean.Level.param `z])
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 3))
                                                (Lean.Expr.bvar 2))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `Subtype.val
                                                      [Lean.Level.succ (Lean.Level.param `w)])
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.lam
                                                    `e
                                                    (Lean.Expr.bvar 4)
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 0)))
                                                      (Lean.Expr.bvar 2))
                                                    (Lean.BinderInfo.default)))
                                                (Lean.Expr.bvar 0)))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.isAddCommGroup
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.bvar 7)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 4)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 2))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 0)))))
                                      (Lean.BinderInfo.default)))))))
                          (Lean.Expr.lam
                            `b
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.bvar 2))
                                  (Lean.Expr.bvar 1))
                                (Lean.Expr.bvar 0)))
                            (Lean.Expr.lam
                              `e
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                          [Lean.Level.param `v, Lean.Level.param `w])
                                        (Lean.Expr.bvar 6))
                                      (Lean.Expr.bvar 5))
                                    (Lean.Expr.bvar 4))
                                  (Lean.Expr.bvar 3))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `DFunLike.coe
                                            [Lean.Level.succ (Lean.Level.param `z),
                                             Lean.Level.succ (Lean.Level.param `z),
                                             Lean.Level.succ (Lean.Level.param `z)])
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `LinearMap
                                                                  [Lean.Level.param `u,
                                                                   Lean.Level.param `u,
                                                                   Lean.Level.param `z,
                                                                   Lean.Level.param `z])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `CommSemiring.toSemiring
                                                                  [Lean.Level.param `u])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `CommRing.toCommSemiring
                                                                    [Lean.Level.param `u])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `CommSemiring.toSemiring
                                                                [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `CommRing.toCommSemiring
                                                                  [Lean.Level.param `u])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Semiring.toNonAssocSemiring
                                                                [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `CommSemiring.toSemiring
                                                                  [Lean.Level.param `u])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `CommRing.toCommSemiring
                                                                    [Lean.Level.param `u])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))))))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `ModuleCat.carrier
                                                              [Lean.Level.param `z, Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8)))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                          [Lean.Level.param `u,
                                                                           Lean.Level.param `v,
                                                                           Lean.Level.param `w,
                                                                           Lean.Level.param `z])
                                                                        (Lean.Expr.bvar 9))
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Subtype.val
                                                                    [Lean.Level.succ (Lean.Level.param `w)])
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.lam
                                                                  `e
                                                                  (Lean.Expr.bvar 5)
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `Eq
                                                                          [Lean.Level.succ (Lean.Level.param `v)])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.app
                                                                                (Lean.Expr.const
                                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                  [Lean.Level.param `v,
                                                                                   Lean.Level.param `w])
                                                                                (Lean.Expr.bvar 8))
                                                                              (Lean.Expr.bvar 7))
                                                                            (Lean.Expr.bvar 6))
                                                                          (Lean.Expr.bvar 5))
                                                                        (Lean.Expr.bvar 0)))
                                                                    (Lean.Expr.bvar 3))
                                                                  (Lean.BinderInfo.default)))
                                                              (Lean.Expr.bvar 0))))))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.carrier
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0)))))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `AddCommGroup.toAddCommMonoid
                                                        [Lean.Level.param `z])
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `ModuleCat.carrier
                                                              [Lean.Level.param `z, Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8)))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                          [Lean.Level.param `u,
                                                                           Lean.Level.param `v,
                                                                           Lean.Level.param `w,
                                                                           Lean.Level.param `z])
                                                                        (Lean.Expr.bvar 9))
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Subtype.val
                                                                    [Lean.Level.succ (Lean.Level.param `w)])
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.lam
                                                                  `e
                                                                  (Lean.Expr.bvar 5)
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `Eq
                                                                          [Lean.Level.succ (Lean.Level.param `v)])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.app
                                                                                (Lean.Expr.const
                                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                  [Lean.Level.param `v,
                                                                                   Lean.Level.param `w])
                                                                                (Lean.Expr.bvar 8))
                                                                              (Lean.Expr.bvar 7))
                                                                            (Lean.Expr.bvar 6))
                                                                          (Lean.Expr.bvar 5))
                                                                        (Lean.Expr.bvar 0)))
                                                                    (Lean.Expr.bvar 3))
                                                                  (Lean.BinderInfo.default)))
                                                              (Lean.Expr.bvar 0))))))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.isAddCommGroup
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `Subtype.val
                                                                  [Lean.Level.succ (Lean.Level.param `w)])
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.lam
                                                                `e
                                                                (Lean.Expr.bvar 5)
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `Eq
                                                                        [Lean.Level.succ (Lean.Level.param `v)])
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.const
                                                                                `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                [Lean.Level.param `v,
                                                                                 Lean.Level.param `w])
                                                                              (Lean.Expr.bvar 8))
                                                                            (Lean.Expr.bvar 7))
                                                                          (Lean.Expr.bvar 6))
                                                                        (Lean.Expr.bvar 5))
                                                                      (Lean.Expr.bvar 0)))
                                                                  (Lean.Expr.bvar 3))
                                                                (Lean.BinderInfo.default)))
                                                            (Lean.Expr.bvar 0)))))))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `AddCommGroup.toAddCommMonoid
                                                      [Lean.Level.param `z])
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.carrier
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0)))))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `ModuleCat.isAddCommGroup
                                                          [Lean.Level.param `z, Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8)))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                      [Lean.Level.param `u,
                                                                       Lean.Level.param `v,
                                                                       Lean.Level.param `w,
                                                                       Lean.Level.param `z])
                                                                    (Lean.Expr.bvar 9))
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Subtype.val
                                                              [Lean.Level.succ (Lean.Level.param `w)])
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.lam
                                                            `e
                                                            (Lean.Expr.bvar 5)
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Eq
                                                                    [Lean.Level.succ (Lean.Level.param `v)])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.const
                                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                                          (Lean.Expr.bvar 8))
                                                                        (Lean.Expr.bvar 7))
                                                                      (Lean.Expr.bvar 6))
                                                                    (Lean.Expr.bvar 5))
                                                                  (Lean.Expr.bvar 0)))
                                                              (Lean.Expr.bvar 3))
                                                            (Lean.BinderInfo.default)))
                                                        (Lean.Expr.bvar 0))))))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `ModuleCat.isModule
                                                      [Lean.Level.param `z, Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.bvar 8)))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                  [Lean.Level.param `u,
                                                                   Lean.Level.param `v,
                                                                   Lean.Level.param `w,
                                                                   Lean.Level.param `z])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 3))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `Subtype.val
                                                            [Lean.Level.succ (Lean.Level.param `w)])
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.lam
                                                          `e
                                                          (Lean.Expr.bvar 5)
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `Eq
                                                                  [Lean.Level.succ (Lean.Level.param `v)])
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.bvar 7))
                                                                    (Lean.Expr.bvar 6))
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.bvar 0)))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.BinderInfo.default)))
                                                      (Lean.Expr.bvar 0))))))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `ModuleCat.isModule
                                                    [Lean.Level.param `z, Lean.Level.param `u])
                                                  (Lean.Expr.bvar 9))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.bvar 8)))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                [Lean.Level.param `u,
                                                                 Lean.Level.param `v,
                                                                 Lean.Level.param `w,
                                                                 Lean.Level.param `z])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 3))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `Subtype.val
                                                        [Lean.Level.succ (Lean.Level.param `w)])
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.lam
                                                      `e
                                                      (Lean.Expr.bvar 5)
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Eq
                                                              [Lean.Level.succ (Lean.Level.param `v)])
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 0)))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.BinderInfo.default)))
                                                  (Lean.Expr.bvar 0))))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                        [Lean.Level.param `v, Lean.Level.param `w])
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `Subtype.val
                                                      [Lean.Level.succ (Lean.Level.param `w)])
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.lam
                                                    `e
                                                    (Lean.Expr.bvar 5)
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 0)))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.BinderInfo.default)))
                                                (Lean.Expr.bvar 0))))))
                                      (Lean.Expr.lam
                                        (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `x.«_@».Mathlib.Data.FunLike.Basic 2582841819) "_hygCtx") "_hyg") 11)
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                        [Lean.Level.param `v, Lean.Level.param `w])
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `Subtype.val
                                                      [Lean.Level.succ (Lean.Level.param `w)])
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.lam
                                                    `e
                                                    (Lean.Expr.bvar 5)
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 0)))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.BinderInfo.default)))
                                                (Lean.Expr.bvar 0)))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 10))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 10))
                                              (Lean.Expr.bvar 9)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 10))
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 6)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 1))))
                                        (Lean.BinderInfo.default)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `LinearMap.instFunLike
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `u,
                                                             Lean.Level.param `z,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `ModuleCat.carrier
                                                              [Lean.Level.param `z, Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8)))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                          [Lean.Level.param `u,
                                                                           Lean.Level.param `v,
                                                                           Lean.Level.param `w,
                                                                           Lean.Level.param `z])
                                                                        (Lean.Expr.bvar 9))
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Subtype.val
                                                                    [Lean.Level.succ (Lean.Level.param `w)])
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.lam
                                                                  `e
                                                                  (Lean.Expr.bvar 5)
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `Eq
                                                                          [Lean.Level.succ (Lean.Level.param `v)])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.app
                                                                                (Lean.Expr.const
                                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                  [Lean.Level.param `v,
                                                                                   Lean.Level.param `w])
                                                                                (Lean.Expr.bvar 8))
                                                                              (Lean.Expr.bvar 7))
                                                                            (Lean.Expr.bvar 6))
                                                                          (Lean.Expr.bvar 5))
                                                                        (Lean.Expr.bvar 0)))
                                                                    (Lean.Expr.bvar 3))
                                                                  (Lean.BinderInfo.default)))
                                                              (Lean.Expr.bvar 0))))))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.carrier
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0)))))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8))))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.bvar 8))))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `ModuleCat.carrier
                                                          [Lean.Level.param `z, Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8)))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                      [Lean.Level.param `u,
                                                                       Lean.Level.param `v,
                                                                       Lean.Level.param `w,
                                                                       Lean.Level.param `z])
                                                                    (Lean.Expr.bvar 9))
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0))))))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `ModuleCat.isAddCommGroup
                                                        [Lean.Level.param `z, Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8)))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                    [Lean.Level.param `u,
                                                                     Lean.Level.param `v,
                                                                     Lean.Level.param `w,
                                                                     Lean.Level.param `z])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 4))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                [Lean.Level.param `v, Lean.Level.param `w])
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 4))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Subtype.val
                                                              [Lean.Level.succ (Lean.Level.param `w)])
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.lam
                                                            `e
                                                            (Lean.Expr.bvar 5)
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Eq
                                                                    [Lean.Level.succ (Lean.Level.param `v)])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.const
                                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                                          (Lean.Expr.bvar 8))
                                                                        (Lean.Expr.bvar 7))
                                                                      (Lean.Expr.bvar 6))
                                                                    (Lean.Expr.bvar 5))
                                                                  (Lean.Expr.bvar 0)))
                                                              (Lean.Expr.bvar 3))
                                                            (Lean.BinderInfo.default)))
                                                        (Lean.Expr.bvar 0)))))))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `ModuleCat.carrier
                                                        [Lean.Level.param `z, Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8)))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                    [Lean.Level.param `u,
                                                                     Lean.Level.param `v,
                                                                     Lean.Level.param `w,
                                                                     Lean.Level.param `z])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 4))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `Subtype.val
                                                            [Lean.Level.succ (Lean.Level.param `w)])
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.lam
                                                          `e
                                                          (Lean.Expr.bvar 5)
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `Eq
                                                                  [Lean.Level.succ (Lean.Level.param `v)])
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.bvar 7))
                                                                    (Lean.Expr.bvar 6))
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.bvar 0)))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.BinderInfo.default)))
                                                      (Lean.Expr.bvar 0)))))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `ModuleCat.isAddCommGroup
                                                      [Lean.Level.param `z, Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.bvar 8)))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                  [Lean.Level.param `u,
                                                                   Lean.Level.param `v,
                                                                   Lean.Level.param `w,
                                                                   Lean.Level.param `z])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 3))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `Subtype.val
                                                          [Lean.Level.succ (Lean.Level.param `w)])
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.lam
                                                        `e
                                                        (Lean.Expr.bvar 5)
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Eq
                                                                [Lean.Level.succ (Lean.Level.param `v)])
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                        [Lean.Level.param `v, Lean.Level.param `w])
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 0)))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.BinderInfo.default)))
                                                    (Lean.Expr.bvar 0))))))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `ModuleCat.isModule
                                                  [Lean.Level.param `z, Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                  (Lean.Expr.bvar 9))
                                                (Lean.Expr.bvar 8)))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                              [Lean.Level.param `u,
                                                               Lean.Level.param `v,
                                                               Lean.Level.param `w,
                                                               Lean.Level.param `z])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `Subtype.val
                                                        [Lean.Level.succ (Lean.Level.param `w)])
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.lam
                                                      `e
                                                      (Lean.Expr.bvar 5)
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Eq
                                                              [Lean.Level.succ (Lean.Level.param `v)])
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 0)))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.BinderInfo.default)))
                                                  (Lean.Expr.bvar 0))))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.isModule
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 5)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 3))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 0)))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                          (Lean.Expr.bvar 9))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Semiring.toNonAssocSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 9))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.lower
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 9))
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.lam
                                          `e
                                          (Lean.Expr.bvar 5)
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 0)))
                                            (Lean.Expr.bvar 3))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `Eq.rec
                                              [Lean.Level.succ (Lean.Level.param `z),
                                               Lean.Level.succ (Lean.Level.param `v)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.lam
                                          (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `x.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 48)
                                          (Lean.Expr.bvar 7)
                                          (Lean.Expr.lam
                                            (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `h.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 49)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 0))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `ModuleCat.carrier
                                                    [Lean.Level.param `z, Lean.Level.param `u])
                                                  (Lean.Expr.bvar 11))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                    (Lean.Expr.bvar 11))
                                                  (Lean.Expr.bvar 10)))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                [Lean.Level.param `u,
                                                                 Lean.Level.param `v,
                                                                 Lean.Level.param `w,
                                                                 Lean.Level.param `z])
                                                              (Lean.Expr.bvar 11))
                                                            (Lean.Expr.bvar 10))
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 1)))
                                            (Lean.BinderInfo.default))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 5)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 3))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap._proof_1
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0))))
                              (Lean.BinderInfo.default))
                            (Lean.BinderInfo.default)))
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap._proof_2
                                          [Lean.Level.param `z,
                                           Lean.Level.param `u,
                                           Lean.Level.param `v,
                                           Lean.Level.param `w])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6))
                                    (Lean.Expr.bvar 5))
                                  (Lean.Expr.bvar 4))
                                (Lean.Expr.bvar 3))
                              (Lean.Expr.bvar 2))
                            (Lean.Expr.bvar 1))
                          (Lean.Expr.bvar 0))))
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap._proof_3
                                      [Lean.Level.param `z,
                                       Lean.Level.param `u,
                                       Lean.Level.param `v,
                                       Lean.Level.param `w])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))
                                (Lean.Expr.bvar 5))
                              (Lean.Expr.bvar 4))
                            (Lean.Expr.bvar 3))
                          (Lean.Expr.bvar 2))
                        (Lean.Expr.bvar 1))
                      (Lean.Expr.bvar 0))))
                (Lean.BinderInfo.default))
              (Lean.BinderInfo.default))
            (Lean.BinderInfo.implicit))
          (Lean.BinderInfo.implicit))
        (Lean.BinderInfo.instImplicit))
      (Lean.BinderInfo.implicit))
    (Lean.BinderInfo.instImplicit))
  (Lean.BinderInfo.implicit)
def newStalkType : Lean.Expr :=
Lean.Expr.forallE
  `R
  (Lean.Expr.sort (Lean.Level.succ (Lean.Level.param `u)))
  (Lean.Expr.forallE
    (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `inst.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 3)
    (Lean.Expr.app (Lean.Expr.const `CommRing [Lean.Level.param `u]) (Lean.Expr.bvar 0))
    (Lean.Expr.forallE
      `V
      (Lean.Expr.sort (Lean.Level.succ (Lean.Level.param `v)))
      (Lean.Expr.forallE
        (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `inst.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 7)
        (Lean.Expr.app (Lean.Expr.const `PartialOrder [Lean.Level.param `v]) (Lean.Expr.bvar 0))
        (Lean.Expr.forallE
          `E
          (Lean.Expr.sort (Lean.Level.succ (Lean.Level.param `w)))
          (Lean.Expr.forallE
            `G
            (Lean.Expr.app
              (Lean.Expr.app
                (Lean.Expr.app
                  (Lean.Expr.const
                    `OAI.KLInvariance.MomentGraph.OrderedGraph
                    [Lean.Level.param `v, Lean.Level.param `w])
                  (Lean.Expr.bvar 2))
                (Lean.Expr.bvar 1))
              (Lean.Expr.bvar 0))
            (Lean.Expr.forallE
              `B
              (Lean.Expr.app
                (Lean.Expr.app
                  (Lean.Expr.app
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.const
                            `OAI.KLInvariance.MomentGraph.Sheaf
                            [Lean.Level.param `u, Lean.Level.param `v, Lean.Level.param `w, Lean.Level.param `z])
                          (Lean.Expr.bvar 5))
                        (Lean.Expr.bvar 4))
                      (Lean.Expr.bvar 3))
                    (Lean.Expr.bvar 2))
                  (Lean.Expr.bvar 1))
                (Lean.Expr.bvar 0))
              (Lean.Expr.forallE
                `x
                (Lean.Expr.bvar 4)
                (Lean.Expr.app
                  (Lean.Expr.app
                    (Lean.Expr.app
                      (Lean.Expr.const
                        `Eq
                        [Lean.Level.max
                           (Lean.Level.succ (Lean.Level.param `z))
                           (Lean.Level.succ (Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)))])
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `LinearMap
                                              [Lean.Level.param `u,
                                               Lean.Level.param `u,
                                               Lean.Level.param `z,
                                               Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Semiring.toNonAssocSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 7))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.bvar 0)))))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `Pi.addCommMonoid [Lean.Level.param `w, Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0)))
                                (Lean.Expr.lam
                                  `e
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.BinderInfo.default)))
                              (Lean.Expr.lam
                                `i
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                            [Lean.Level.param `v, Lean.Level.param `w])
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.bvar 2))
                                  (Lean.Expr.bvar 0))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0)))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `ModuleCat.isAddCommGroup
                                          [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.BinderInfo.default))))
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.bvar 6)))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                              [Lean.Level.param `u,
                                               Lean.Level.param `v,
                                               Lean.Level.param `w,
                                               Lean.Level.param `z])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.bvar 0))))
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `Pi.module
                                      [Lean.Level.param `w, Lean.Level.param `z, Lean.Level.param `u])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0)))
                                  (Lean.Expr.lam
                                    `e
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0))))
                                    (Lean.BinderInfo.default)))
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))))
                            (Lean.Expr.lam
                              `i
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                          [Lean.Level.param `v, Lean.Level.param `w])
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 0))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 8))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.bvar 7)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.lam
                                          `e
                                          (Lean.Expr.bvar 4)
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 0)))
                                            (Lean.Expr.bvar 2))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 0)))))
                              (Lean.BinderInfo.default)))
                          (Lean.Expr.lam
                            `i
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                        [Lean.Level.param `v, Lean.Level.param `w])
                                      (Lean.Expr.bvar 5))
                                    (Lean.Expr.bvar 4))
                                  (Lean.Expr.bvar 3))
                                (Lean.Expr.bvar 2))
                              (Lean.Expr.bvar 0))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 8))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 8))
                                  (Lean.Expr.bvar 7)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.lam
                                      `e
                                      (Lean.Expr.bvar 4)
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 0)))
                                        (Lean.Expr.bvar 2))
                                      (Lean.BinderInfo.default)))
                                  (Lean.Expr.bvar 0))))
                            (Lean.BinderInfo.default)))))
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap
                                      [Lean.Level.param `u,
                                       Lean.Level.param `v,
                                       Lean.Level.param `w,
                                       Lean.Level.param `z])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))
                                (Lean.Expr.bvar 5))
                              (Lean.Expr.bvar 4))
                            (Lean.Expr.bvar 3))
                          (Lean.Expr.bvar 2))
                        (Lean.Expr.bvar 1))
                      (Lean.Expr.bvar 0)))
                  (Lean.Expr.app
                    (Lean.Expr.app
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `LinearMap.mk
                                              [Lean.Level.param `u,
                                               Lean.Level.param `u,
                                               Lean.Level.param `z,
                                               Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Semiring.toNonAssocSemiring [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 7))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.bvar 0)))))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `Pi.addCommMonoid [Lean.Level.param `w, Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0)))
                                (Lean.Expr.lam
                                  `e
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                              [Lean.Level.param `v, Lean.Level.param `w])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.BinderInfo.default)))
                              (Lean.Expr.lam
                                `i
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                            [Lean.Level.param `v, Lean.Level.param `w])
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.bvar 2))
                                  (Lean.Expr.bvar 0))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0)))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `ModuleCat.isAddCommGroup
                                          [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.BinderInfo.default))))
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.bvar 6)))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                              [Lean.Level.param `u,
                                               Lean.Level.param `v,
                                               Lean.Level.param `w,
                                               Lean.Level.param `z])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.bvar 0))))
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `Pi.module
                                      [Lean.Level.param `w, Lean.Level.param `z, Lean.Level.param `u])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0)))
                                  (Lean.Expr.lam
                                    `e
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 0))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 8))
                                          (Lean.Expr.bvar 7)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.lam
                                              `e
                                              (Lean.Expr.bvar 4)
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 0)))
                                                (Lean.Expr.bvar 2))
                                              (Lean.BinderInfo.default)))
                                          (Lean.Expr.bvar 0))))
                                    (Lean.BinderInfo.default)))
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6))))
                            (Lean.Expr.lam
                              `i
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                          [Lean.Level.param `v, Lean.Level.param `w])
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 0))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 8))
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 4)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 2))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0)))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `ModuleCat.isAddCommGroup
                                        [Lean.Level.param `z, Lean.Level.param `u])
                                      (Lean.Expr.bvar 8))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                        (Lean.Expr.bvar 8))
                                      (Lean.Expr.bvar 7)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.lam
                                          `e
                                          (Lean.Expr.bvar 4)
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 0)))
                                            (Lean.Expr.bvar 2))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 0)))))
                              (Lean.BinderInfo.default)))
                          (Lean.Expr.lam
                            `i
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const
                                        `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                        [Lean.Level.param `v, Lean.Level.param `w])
                                      (Lean.Expr.bvar 5))
                                    (Lean.Expr.bvar 4))
                                  (Lean.Expr.bvar 3))
                                (Lean.Expr.bvar 2))
                              (Lean.Expr.bvar 0))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.isModule [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 8))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 8))
                                  (Lean.Expr.bvar 7)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.lam
                                      `e
                                      (Lean.Expr.bvar 4)
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 0)))
                                        (Lean.Expr.bvar 2))
                                      (Lean.BinderInfo.default)))
                                  (Lean.Expr.bvar 0))))
                            (Lean.BinderInfo.default))))
                      (Lean.Expr.app
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const
                                    `AddHom.mk
                                    [Lean.Level.param `z, Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `AddCommMagma.toAdd [Lean.Level.param `z])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.bvar 6)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `AddCommSemigroup.toAddCommMagma [Lean.Level.param `z])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `ModuleCat.carrier
                                            [Lean.Level.param `z, Lean.Level.param `u])
                                          (Lean.Expr.bvar 7))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6)))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                        [Lean.Level.param `u,
                                                         Lean.Level.param `v,
                                                         Lean.Level.param `w,
                                                         Lean.Level.param `z])
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.bvar 2))
                                          (Lean.Expr.bvar 1))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.const `AddCommMonoid.toAddCommSemigroup [Lean.Level.param `z])
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `ModuleCat.carrier
                                              [Lean.Level.param `z, Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6)))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                          [Lean.Level.param `u,
                                                           Lean.Level.param `v,
                                                           Lean.Level.param `w,
                                                           Lean.Level.param `z])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.bvar 1))
                                          (Lean.Expr.bvar 0))))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 3))
                                                (Lean.Expr.bvar 2))
                                              (Lean.Expr.bvar 1))
                                            (Lean.Expr.bvar 0))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `ModuleCat.isAddCommGroup
                                              [Lean.Level.param `z, Lean.Level.param `u])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6)))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                          [Lean.Level.param `u,
                                                           Lean.Level.param `v,
                                                           Lean.Level.param `w,
                                                           Lean.Level.param `z])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.bvar 1))
                                          (Lean.Expr.bvar 0))))))))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const
                                  `AddCommMagma.toAdd
                                  [Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                  [Lean.Level.param `u,
                                                   Lean.Level.param `v,
                                                   Lean.Level.param `w,
                                                   Lean.Level.param `z])
                                                (Lean.Expr.bvar 7))
                                              (Lean.Expr.bvar 6))
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.bvar 4))
                                        (Lean.Expr.bvar 3))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 1))
                                  (Lean.Expr.bvar 0)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const
                                    `AddCommSemigroup.toAddCommMagma
                                    [Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 7))
                                                (Lean.Expr.bvar 6))
                                              (Lean.Expr.bvar 5))
                                            (Lean.Expr.bvar 4))
                                          (Lean.Expr.bvar 3))
                                        (Lean.Expr.bvar 2))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.bvar 0)))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const
                                      `AddCommMonoid.toAddCommSemigroup
                                      [Lean.Level.max (Lean.Level.param `w) (Lean.Level.param `z)])
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `OAI.KLInvariance.MomentGraph.Sheaf.Boundary
                                                      [Lean.Level.param `u,
                                                       Lean.Level.param `v,
                                                       Lean.Level.param `w,
                                                       Lean.Level.param `z])
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 1))
                                      (Lean.Expr.bvar 0)))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const `Pi.addCommMonoid [Lean.Level.param `w, Lean.Level.param `z])
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.bvar 2))
                                          (Lean.Expr.bvar 0)))
                                      (Lean.Expr.lam
                                        `e
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.bvar 2))
                                          (Lean.Expr.bvar 0))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.bvar 7)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 4)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 2))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 0))))
                                        (Lean.BinderInfo.default)))
                                    (Lean.Expr.lam
                                      `i
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.bvar 3))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.bvar 0))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `ModuleCat.carrier
                                                  [Lean.Level.param `z, Lean.Level.param `u])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 7)))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                              [Lean.Level.param `u,
                                                               Lean.Level.param `v,
                                                               Lean.Level.param `w,
                                                               Lean.Level.param `z])
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 3))
                                                (Lean.Expr.bvar 2))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `Subtype.val
                                                      [Lean.Level.succ (Lean.Level.param `w)])
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.lam
                                                    `e
                                                    (Lean.Expr.bvar 4)
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 0)))
                                                      (Lean.Expr.bvar 2))
                                                    (Lean.BinderInfo.default)))
                                                (Lean.Expr.bvar 0)))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.isAddCommGroup
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.bvar 7)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 2))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 4)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 2))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 0)))))
                                      (Lean.BinderInfo.default)))))))
                          (Lean.Expr.lam
                            `b
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 7))
                                  (Lean.Expr.bvar 6)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.bvar 2))
                                  (Lean.Expr.bvar 1))
                                (Lean.Expr.bvar 0)))
                            (Lean.Expr.lam
                              `e
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.const
                                          `OAI.KLInvariance.MomentGraph.Sheaf.Outgoing
                                          [Lean.Level.param `v, Lean.Level.param `w])
                                        (Lean.Expr.bvar 6))
                                      (Lean.Expr.bvar 5))
                                    (Lean.Expr.bvar 4))
                                  (Lean.Expr.bvar 3))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `DFunLike.coe
                                            [Lean.Level.succ (Lean.Level.param `z),
                                             Lean.Level.succ (Lean.Level.param `z),
                                             Lean.Level.succ (Lean.Level.param `z)])
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `LinearMap
                                                                  [Lean.Level.param `u,
                                                                   Lean.Level.param `u,
                                                                   Lean.Level.param `z,
                                                                   Lean.Level.param `z])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `CommSemiring.toSemiring
                                                                  [Lean.Level.param `u])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `CommRing.toCommSemiring
                                                                    [Lean.Level.param `u])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `CommSemiring.toSemiring
                                                                [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `CommRing.toCommSemiring
                                                                  [Lean.Level.param `u])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Semiring.toNonAssocSemiring
                                                                [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `CommSemiring.toSemiring
                                                                  [Lean.Level.param `u])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `CommRing.toCommSemiring
                                                                    [Lean.Level.param `u])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))))))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `ModuleCat.carrier
                                                              [Lean.Level.param `z, Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8)))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                          [Lean.Level.param `u,
                                                                           Lean.Level.param `v,
                                                                           Lean.Level.param `w,
                                                                           Lean.Level.param `z])
                                                                        (Lean.Expr.bvar 9))
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Subtype.val
                                                                    [Lean.Level.succ (Lean.Level.param `w)])
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.lam
                                                                  `e
                                                                  (Lean.Expr.bvar 5)
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `Eq
                                                                          [Lean.Level.succ (Lean.Level.param `v)])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.app
                                                                                (Lean.Expr.const
                                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                  [Lean.Level.param `v,
                                                                                   Lean.Level.param `w])
                                                                                (Lean.Expr.bvar 8))
                                                                              (Lean.Expr.bvar 7))
                                                                            (Lean.Expr.bvar 6))
                                                                          (Lean.Expr.bvar 5))
                                                                        (Lean.Expr.bvar 0)))
                                                                    (Lean.Expr.bvar 3))
                                                                  (Lean.BinderInfo.default)))
                                                              (Lean.Expr.bvar 0))))))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.carrier
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0)))))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `AddCommGroup.toAddCommMonoid
                                                        [Lean.Level.param `z])
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `ModuleCat.carrier
                                                              [Lean.Level.param `z, Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8)))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                          [Lean.Level.param `u,
                                                                           Lean.Level.param `v,
                                                                           Lean.Level.param `w,
                                                                           Lean.Level.param `z])
                                                                        (Lean.Expr.bvar 9))
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Subtype.val
                                                                    [Lean.Level.succ (Lean.Level.param `w)])
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.lam
                                                                  `e
                                                                  (Lean.Expr.bvar 5)
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `Eq
                                                                          [Lean.Level.succ (Lean.Level.param `v)])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.app
                                                                                (Lean.Expr.const
                                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                  [Lean.Level.param `v,
                                                                                   Lean.Level.param `w])
                                                                                (Lean.Expr.bvar 8))
                                                                              (Lean.Expr.bvar 7))
                                                                            (Lean.Expr.bvar 6))
                                                                          (Lean.Expr.bvar 5))
                                                                        (Lean.Expr.bvar 0)))
                                                                    (Lean.Expr.bvar 3))
                                                                  (Lean.BinderInfo.default)))
                                                              (Lean.Expr.bvar 0))))))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.isAddCommGroup
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `Subtype.val
                                                                  [Lean.Level.succ (Lean.Level.param `w)])
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.lam
                                                                `e
                                                                (Lean.Expr.bvar 5)
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `Eq
                                                                        [Lean.Level.succ (Lean.Level.param `v)])
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.const
                                                                                `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                [Lean.Level.param `v,
                                                                                 Lean.Level.param `w])
                                                                              (Lean.Expr.bvar 8))
                                                                            (Lean.Expr.bvar 7))
                                                                          (Lean.Expr.bvar 6))
                                                                        (Lean.Expr.bvar 5))
                                                                      (Lean.Expr.bvar 0)))
                                                                  (Lean.Expr.bvar 3))
                                                                (Lean.BinderInfo.default)))
                                                            (Lean.Expr.bvar 0)))))))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `AddCommGroup.toAddCommMonoid
                                                      [Lean.Level.param `z])
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.carrier
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0)))))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `ModuleCat.isAddCommGroup
                                                          [Lean.Level.param `z, Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8)))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                      [Lean.Level.param `u,
                                                                       Lean.Level.param `v,
                                                                       Lean.Level.param `w,
                                                                       Lean.Level.param `z])
                                                                    (Lean.Expr.bvar 9))
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Subtype.val
                                                              [Lean.Level.succ (Lean.Level.param `w)])
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.lam
                                                            `e
                                                            (Lean.Expr.bvar 5)
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Eq
                                                                    [Lean.Level.succ (Lean.Level.param `v)])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.const
                                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                                          (Lean.Expr.bvar 8))
                                                                        (Lean.Expr.bvar 7))
                                                                      (Lean.Expr.bvar 6))
                                                                    (Lean.Expr.bvar 5))
                                                                  (Lean.Expr.bvar 0)))
                                                              (Lean.Expr.bvar 3))
                                                            (Lean.BinderInfo.default)))
                                                        (Lean.Expr.bvar 0))))))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `ModuleCat.isModule
                                                      [Lean.Level.param `z, Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.bvar 8)))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                  [Lean.Level.param `u,
                                                                   Lean.Level.param `v,
                                                                   Lean.Level.param `w,
                                                                   Lean.Level.param `z])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 3))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                              [Lean.Level.param `v, Lean.Level.param `w])
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `Subtype.val
                                                            [Lean.Level.succ (Lean.Level.param `w)])
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.lam
                                                          `e
                                                          (Lean.Expr.bvar 5)
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `Eq
                                                                  [Lean.Level.succ (Lean.Level.param `v)])
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.bvar 7))
                                                                    (Lean.Expr.bvar 6))
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.bvar 0)))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.BinderInfo.default)))
                                                      (Lean.Expr.bvar 0))))))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `ModuleCat.isModule
                                                    [Lean.Level.param `z, Lean.Level.param `u])
                                                  (Lean.Expr.bvar 9))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.bvar 8)))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                [Lean.Level.param `u,
                                                                 Lean.Level.param `v,
                                                                 Lean.Level.param `w,
                                                                 Lean.Level.param `z])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.bvar 7))
                                                        (Lean.Expr.bvar 6))
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.Expr.bvar 3))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `Subtype.val
                                                        [Lean.Level.succ (Lean.Level.param `w)])
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.lam
                                                      `e
                                                      (Lean.Expr.bvar 5)
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Eq
                                                              [Lean.Level.succ (Lean.Level.param `v)])
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 0)))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.BinderInfo.default)))
                                                  (Lean.Expr.bvar 0))))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                        [Lean.Level.param `v, Lean.Level.param `w])
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `Subtype.val
                                                      [Lean.Level.succ (Lean.Level.param `w)])
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.lam
                                                    `e
                                                    (Lean.Expr.bvar 5)
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 0)))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.BinderInfo.default)))
                                                (Lean.Expr.bvar 0))))))
                                      (Lean.Expr.lam
                                        (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `x.«_@».Mathlib.Data.FunLike.Basic 2582841819) "_hygCtx") "_hyg") 11)
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                        [Lean.Level.param `v, Lean.Level.param `w])
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `Subtype.val
                                                      [Lean.Level.succ (Lean.Level.param `w)])
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.lam
                                                    `e
                                                    (Lean.Expr.bvar 5)
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                    [Lean.Level.param `v, Lean.Level.param `w])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 0)))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.BinderInfo.default)))
                                                (Lean.Expr.bvar 0)))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.carrier
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 10))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 10))
                                              (Lean.Expr.bvar 9)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 10))
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8))
                                                    (Lean.Expr.bvar 7))
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.bvar 5))
                                              (Lean.Expr.bvar 4))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 6))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 6)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 4))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 1))))
                                        (Lean.BinderInfo.default)))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `LinearMap.instFunLike
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `u,
                                                             Lean.Level.param `z,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `ModuleCat.carrier
                                                              [Lean.Level.param `z, Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                              (Lean.Expr.bvar 9))
                                                            (Lean.Expr.bvar 8)))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                          [Lean.Level.param `u,
                                                                           Lean.Level.param `v,
                                                                           Lean.Level.param `w,
                                                                           Lean.Level.param `z])
                                                                        (Lean.Expr.bvar 9))
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 4))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Subtype.val
                                                                    [Lean.Level.succ (Lean.Level.param `w)])
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.lam
                                                                  `e
                                                                  (Lean.Expr.bvar 5)
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `Eq
                                                                          [Lean.Level.succ (Lean.Level.param `v)])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.app
                                                                              (Lean.Expr.app
                                                                                (Lean.Expr.const
                                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                                  [Lean.Level.param `v,
                                                                                   Lean.Level.param `w])
                                                                                (Lean.Expr.bvar 8))
                                                                              (Lean.Expr.bvar 7))
                                                                            (Lean.Expr.bvar 6))
                                                                          (Lean.Expr.bvar 5))
                                                                        (Lean.Expr.bvar 0)))
                                                                    (Lean.Expr.bvar 3))
                                                                  (Lean.BinderInfo.default)))
                                                              (Lean.Expr.bvar 0))))))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `ModuleCat.carrier
                                                            [Lean.Level.param `z, Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8)))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                        [Lean.Level.param `u,
                                                                         Lean.Level.param `v,
                                                                         Lean.Level.param `w,
                                                                         Lean.Level.param `z])
                                                                      (Lean.Expr.bvar 9))
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 4))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0)))))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8))))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.bvar 8))))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `ModuleCat.carrier
                                                          [Lean.Level.param `z, Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8)))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                      [Lean.Level.param `u,
                                                                       Lean.Level.param `v,
                                                                       Lean.Level.param `w,
                                                                       Lean.Level.param `z])
                                                                    (Lean.Expr.bvar 9))
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 7))
                                                              (Lean.Expr.bvar 6))
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.bvar 4))
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Subtype.val
                                                                [Lean.Level.succ (Lean.Level.param `w)])
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.lam
                                                              `e
                                                              (Lean.Expr.bvar 5)
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `Eq
                                                                      [Lean.Level.succ (Lean.Level.param `v)])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.app
                                                                            (Lean.Expr.const
                                                                              `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                              [Lean.Level.param `v,
                                                                               Lean.Level.param `w])
                                                                            (Lean.Expr.bvar 8))
                                                                          (Lean.Expr.bvar 7))
                                                                        (Lean.Expr.bvar 6))
                                                                      (Lean.Expr.bvar 5))
                                                                    (Lean.Expr.bvar 0)))
                                                                (Lean.Expr.bvar 3))
                                                              (Lean.BinderInfo.default)))
                                                          (Lean.Expr.bvar 0))))))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `ModuleCat.isAddCommGroup
                                                        [Lean.Level.param `z, Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8)))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                    [Lean.Level.param `u,
                                                                     Lean.Level.param `v,
                                                                     Lean.Level.param `w,
                                                                     Lean.Level.param `z])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 4))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                [Lean.Level.param `v, Lean.Level.param `w])
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 4))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Subtype.val
                                                              [Lean.Level.succ (Lean.Level.param `w)])
                                                            (Lean.Expr.bvar 5))
                                                          (Lean.Expr.lam
                                                            `e
                                                            (Lean.Expr.bvar 5)
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `Eq
                                                                    [Lean.Level.succ (Lean.Level.param `v)])
                                                                  (Lean.Expr.bvar 8))
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.app
                                                                          (Lean.Expr.const
                                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                                          (Lean.Expr.bvar 8))
                                                                        (Lean.Expr.bvar 7))
                                                                      (Lean.Expr.bvar 6))
                                                                    (Lean.Expr.bvar 5))
                                                                  (Lean.Expr.bvar 0)))
                                                              (Lean.Expr.bvar 3))
                                                            (Lean.BinderInfo.default)))
                                                        (Lean.Expr.bvar 0)))))))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `AddCommGroup.toAddCommMonoid [Lean.Level.param `z])
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `ModuleCat.carrier
                                                        [Lean.Level.param `z, Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                        (Lean.Expr.bvar 9))
                                                      (Lean.Expr.bvar 8)))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.const
                                                                    `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                    [Lean.Level.param `u,
                                                                     Lean.Level.param `v,
                                                                     Lean.Level.param `w,
                                                                     Lean.Level.param `z])
                                                                  (Lean.Expr.bvar 9))
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 4))
                                                      (Lean.Expr.bvar 3))
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `Subtype.val
                                                            [Lean.Level.succ (Lean.Level.param `w)])
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.lam
                                                          `e
                                                          (Lean.Expr.bvar 5)
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `Eq
                                                                  [Lean.Level.succ (Lean.Level.param `v)])
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.app
                                                                        (Lean.Expr.const
                                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                                        (Lean.Expr.bvar 8))
                                                                      (Lean.Expr.bvar 7))
                                                                    (Lean.Expr.bvar 6))
                                                                  (Lean.Expr.bvar 5))
                                                                (Lean.Expr.bvar 0)))
                                                            (Lean.Expr.bvar 3))
                                                          (Lean.BinderInfo.default)))
                                                      (Lean.Expr.bvar 0)))))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const
                                                      `ModuleCat.isAddCommGroup
                                                      [Lean.Level.param `z, Lean.Level.param `u])
                                                    (Lean.Expr.bvar 9))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                      (Lean.Expr.bvar 9))
                                                    (Lean.Expr.bvar 8)))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                                  [Lean.Level.param `u,
                                                                   Lean.Level.param `v,
                                                                   Lean.Level.param `w,
                                                                   Lean.Level.param `z])
                                                                (Lean.Expr.bvar 9))
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.bvar 7))
                                                          (Lean.Expr.bvar 6))
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.bvar 4))
                                                    (Lean.Expr.bvar 3))
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `Subtype.val
                                                          [Lean.Level.succ (Lean.Level.param `w)])
                                                        (Lean.Expr.bvar 5))
                                                      (Lean.Expr.lam
                                                        `e
                                                        (Lean.Expr.bvar 5)
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `Eq
                                                                [Lean.Level.succ (Lean.Level.param `v)])
                                                              (Lean.Expr.bvar 8))
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.app
                                                                      (Lean.Expr.const
                                                                        `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                        [Lean.Level.param `v, Lean.Level.param `w])
                                                                      (Lean.Expr.bvar 8))
                                                                    (Lean.Expr.bvar 7))
                                                                  (Lean.Expr.bvar 6))
                                                                (Lean.Expr.bvar 5))
                                                              (Lean.Expr.bvar 0)))
                                                          (Lean.Expr.bvar 3))
                                                        (Lean.BinderInfo.default)))
                                                    (Lean.Expr.bvar 0))))))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `ModuleCat.isModule
                                                  [Lean.Level.param `z, Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                  (Lean.Expr.bvar 9))
                                                (Lean.Expr.bvar 8)))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                              [Lean.Level.param `u,
                                                               Lean.Level.param `v,
                                                               Lean.Level.param `w,
                                                               Lean.Level.param `z])
                                                            (Lean.Expr.bvar 9))
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 4))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.const
                                                        `Subtype.val
                                                        [Lean.Level.succ (Lean.Level.param `w)])
                                                      (Lean.Expr.bvar 5))
                                                    (Lean.Expr.lam
                                                      `e
                                                      (Lean.Expr.bvar 5)
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.const
                                                              `Eq
                                                              [Lean.Level.succ (Lean.Level.param `v)])
                                                            (Lean.Expr.bvar 8))
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.app
                                                                  (Lean.Expr.app
                                                                    (Lean.Expr.const
                                                                      `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                      [Lean.Level.param `v, Lean.Level.param `w])
                                                                    (Lean.Expr.bvar 8))
                                                                  (Lean.Expr.bvar 7))
                                                                (Lean.Expr.bvar 6))
                                                              (Lean.Expr.bvar 5))
                                                            (Lean.Expr.bvar 0)))
                                                        (Lean.Expr.bvar 3))
                                                      (Lean.BinderInfo.default)))
                                                  (Lean.Expr.bvar 0))))))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `ModuleCat.isModule
                                                [Lean.Level.param `z, Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.Sheaf.edge
                                                            [Lean.Level.param `u,
                                                             Lean.Level.param `v,
                                                             Lean.Level.param `w,
                                                             Lean.Level.param `z])
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 4))
                                              (Lean.Expr.bvar 3))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.lam
                                                  `e
                                                  (Lean.Expr.bvar 5)
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.app
                                                                (Lean.Expr.const
                                                                  `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                                  [Lean.Level.param `v, Lean.Level.param `w])
                                                                (Lean.Expr.bvar 8))
                                                              (Lean.Expr.bvar 7))
                                                            (Lean.Expr.bvar 6))
                                                          (Lean.Expr.bvar 5))
                                                        (Lean.Expr.bvar 0)))
                                                    (Lean.Expr.bvar 3))
                                                  (Lean.BinderInfo.default)))
                                              (Lean.Expr.bvar 0)))))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `RingHom.id [Lean.Level.param `u])
                                          (Lean.Expr.bvar 9))
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Semiring.toNonAssocSemiring [Lean.Level.param `u])
                                            (Lean.Expr.bvar 9))
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const `CommSemiring.toSemiring [Lean.Level.param `u])
                                              (Lean.Expr.bvar 9))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `CommRing.toCommSemiring [Lean.Level.param `u])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8)))))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `OAI.KLInvariance.MomentGraph.Sheaf.lower
                                                    [Lean.Level.param `u,
                                                     Lean.Level.param `v,
                                                     Lean.Level.param `w,
                                                     Lean.Level.param `z])
                                                  (Lean.Expr.bvar 9))
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 3))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.lam
                                          `e
                                          (Lean.Expr.bvar 5)
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                (Lean.Expr.bvar 8))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.const
                                                          `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                          [Lean.Level.param `v, Lean.Level.param `w])
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 0)))
                                            (Lean.Expr.bvar 3))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 0))))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `Eq.rec
                                              [Lean.Level.succ (Lean.Level.param `z),
                                               Lean.Level.succ (Lean.Level.param `v)])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 2))
                                        (Lean.Expr.lam
                                          (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `x.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 48)
                                          (Lean.Expr.bvar 7)
                                          (Lean.Expr.lam
                                            (Lean.Name.mkNum (Lean.Name.mkStr (Lean.Name.mkStr (Lean.Name.mkNum `h.«_@».ForMathlib.Combinatorics.MomentGraph.Sheaf.Basic 1526541304) "_hygCtx") "_hyg") 49)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.bvar 3))
                                              (Lean.Expr.bvar 0))
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const
                                                    `ModuleCat.carrier
                                                    [Lean.Level.param `z, Lean.Level.param `u])
                                                  (Lean.Expr.bvar 11))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                                    (Lean.Expr.bvar 11))
                                                  (Lean.Expr.bvar 10)))
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.app
                                                            (Lean.Expr.app
                                                              (Lean.Expr.const
                                                                `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                                [Lean.Level.param `u,
                                                                 Lean.Level.param `v,
                                                                 Lean.Level.param `w,
                                                                 Lean.Level.param `z])
                                                              (Lean.Expr.bvar 11))
                                                            (Lean.Expr.bvar 10))
                                                          (Lean.Expr.bvar 9))
                                                        (Lean.Expr.bvar 8))
                                                      (Lean.Expr.bvar 7))
                                                    (Lean.Expr.bvar 6))
                                                  (Lean.Expr.bvar 5))
                                                (Lean.Expr.bvar 1)))
                                            (Lean.BinderInfo.default))
                                          (Lean.BinderInfo.default)))
                                      (Lean.Expr.bvar 1))
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const `Subtype.val [Lean.Level.succ (Lean.Level.param `w)])
                                            (Lean.Expr.bvar 5))
                                          (Lean.Expr.lam
                                            `e
                                            (Lean.Expr.bvar 5)
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.app
                                                  (Lean.Expr.const `Eq [Lean.Level.succ (Lean.Level.param `v)])
                                                  (Lean.Expr.bvar 8))
                                                (Lean.Expr.app
                                                  (Lean.Expr.app
                                                    (Lean.Expr.app
                                                      (Lean.Expr.app
                                                        (Lean.Expr.app
                                                          (Lean.Expr.const
                                                            `OAI.KLInvariance.MomentGraph.OrderedGraph.source
                                                            [Lean.Level.param `v, Lean.Level.param `w])
                                                          (Lean.Expr.bvar 8))
                                                        (Lean.Expr.bvar 7))
                                                      (Lean.Expr.bvar 6))
                                                    (Lean.Expr.bvar 5))
                                                  (Lean.Expr.bvar 0)))
                                              (Lean.Expr.bvar 3))
                                            (Lean.BinderInfo.default)))
                                        (Lean.Expr.bvar 0))))
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap._proof_3
                                                [Lean.Level.param `v, Lean.Level.param `w])
                                              (Lean.Expr.bvar 7))
                                            (Lean.Expr.bvar 6))
                                          (Lean.Expr.bvar 5))
                                        (Lean.Expr.bvar 4))
                                      (Lean.Expr.bvar 2))
                                    (Lean.Expr.bvar 0))))
                              (Lean.BinderInfo.default))
                            (Lean.BinderInfo.default)))
                        (Lean.Expr.lam
                          `b
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                (Lean.Expr.bvar 7))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                  (Lean.Expr.bvar 7))
                                (Lean.Expr.bvar 6)))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                              [Lean.Level.param `u,
                                               Lean.Level.param `v,
                                               Lean.Level.param `w,
                                               Lean.Level.param `z])
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.bvar 0)))
                          (Lean.Expr.lam
                            `c
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                                  (Lean.Expr.bvar 8))
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                    (Lean.Expr.bvar 8))
                                  (Lean.Expr.bvar 7)))
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.const
                                                `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                                [Lean.Level.param `u,
                                                 Lean.Level.param `v,
                                                 Lean.Level.param `w,
                                                 Lean.Level.param `z])
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1)))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.app
                                              (Lean.Expr.app
                                                (Lean.Expr.const
                                                  `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap._proof_1
                                                  [Lean.Level.param `w,
                                                   Lean.Level.param `z,
                                                   Lean.Level.param `u,
                                                   Lean.Level.param `v])
                                                (Lean.Expr.bvar 9))
                                              (Lean.Expr.bvar 8))
                                            (Lean.Expr.bvar 7))
                                          (Lean.Expr.bvar 6))
                                        (Lean.Expr.bvar 5))
                                      (Lean.Expr.bvar 4))
                                    (Lean.Expr.bvar 3))
                                  (Lean.Expr.bvar 2))
                                (Lean.Expr.bvar 1))
                              (Lean.Expr.bvar 0))
                            (Lean.BinderInfo.default))
                          (Lean.BinderInfo.default))))
                    (Lean.Expr.lam
                      `r
                      (Lean.Expr.bvar 7)
                      (Lean.Expr.lam
                        `b
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.const `ModuleCat.carrier [Lean.Level.param `z, Lean.Level.param `u])
                              (Lean.Expr.bvar 8))
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.const `CommRing.toRing [Lean.Level.param `u])
                                (Lean.Expr.bvar 8))
                              (Lean.Expr.bvar 7)))
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.const
                                            `OAI.KLInvariance.MomentGraph.Sheaf.vertex
                                            [Lean.Level.param `u,
                                             Lean.Level.param `v,
                                             Lean.Level.param `w,
                                             Lean.Level.param `z])
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6))
                                    (Lean.Expr.bvar 5))
                                  (Lean.Expr.bvar 4))
                                (Lean.Expr.bvar 3))
                              (Lean.Expr.bvar 2))
                            (Lean.Expr.bvar 1)))
                        (Lean.Expr.app
                          (Lean.Expr.app
                            (Lean.Expr.app
                              (Lean.Expr.app
                                (Lean.Expr.app
                                  (Lean.Expr.app
                                    (Lean.Expr.app
                                      (Lean.Expr.app
                                        (Lean.Expr.app
                                          (Lean.Expr.app
                                            (Lean.Expr.const
                                              `OAI.KLInvariance.MomentGraph.Sheaf.stalkMap._proof_2
                                              [Lean.Level.param `w,
                                               Lean.Level.param `z,
                                               Lean.Level.param `u,
                                               Lean.Level.param `v])
                                            (Lean.Expr.bvar 9))
                                          (Lean.Expr.bvar 8))
                                        (Lean.Expr.bvar 7))
                                      (Lean.Expr.bvar 6))
                                    (Lean.Expr.bvar 5))
                                  (Lean.Expr.bvar 4))
                                (Lean.Expr.bvar 3))
                              (Lean.Expr.bvar 2))
                            (Lean.Expr.bvar 1))
                          (Lean.Expr.bvar 0))
                        (Lean.BinderInfo.default))
                      (Lean.BinderInfo.default))))
                (Lean.BinderInfo.default))
              (Lean.BinderInfo.default))
            (Lean.BinderInfo.implicit))
          (Lean.BinderInfo.implicit))
        (Lean.BinderInfo.instImplicit))
      (Lean.BinderInfo.implicit))
    (Lean.BinderInfo.instImplicit))
  (Lean.BinderInfo.implicit)
run_elab do
  unless !(ExprStructEq.mk oldStalkType == ExprStructEq.mk newStalkType) do
    throwError "expected different stored equation expressions"
  Lean.Meta.check oldStalkType
  Lean.Meta.check newStalkType
  unless ← isDefEq oldStalkType newStalkType do
    throwError "actual stalk equation types are not definitionally equal in the modern full environment"
  logInfo "actual stalkMap.eq_1 types: different stored expressions; both well-typed; definitional equality passes"
